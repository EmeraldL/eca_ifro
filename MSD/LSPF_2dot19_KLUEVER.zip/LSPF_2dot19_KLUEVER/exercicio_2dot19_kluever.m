%Porto Velho - RO, 6 de novembro de 2019 - Larissa Samara Paula de França.
%Exercício 2.19 (KLUEVER)

%Definindo as variáveis.
F_est = 10; %Força de atrito estática.
Fc = 7; %Força de atrico coulomb.
b = 70; % coeficiente de atrito viscoso.
c1 = 0.001; %coeficiente de velocidade 1.
c2 = 0.002; %coeficiente de velocidade 2.
c3 = 0.005; %coeficiente de velocidade 3.
x_dot = linspace(-0.05,0.05,1000); %Range da velocidade relativa.

%Equação da força de atrito total para os três coeficientes de velocidades.
Fa1 = sign(x_dot).* (Fc + (F_est-Fc).*exp(-abs(x_dot)./c1)) + b.*x_dot;
Fa2 = sign(x_dot).* (Fc + (F_est-Fc).*exp(-abs(x_dot)./c2)) + b.*x_dot;
Fa3 = sign(x_dot).* (Fc + (F_est-Fc).*exp(-abs(x_dot)./c3)) + b.*x_dot;

hold on; %Permite plotar todos os gráficos juntos.
plot(x_dot,Fa1,'red'); %Gráfico para c1.
plot(x_dot,Fa2,'green'); %Gráfico para c2.
plot(x_dot,Fa3,'blue'); %Gráfico para c3.

title('Exercício 2.19 (KLUEVER)'); %Título do gráfico.
xlabel('Velocidade relativa (m/s)'); %Nome do eixo x.
ylabel('Força de atrito (N^-1)'); %Nome do eixo y.
legend('c1 = 0,001','c2 = 0,002','c3 = 0,005'); %Legenda. OBS: ajustar arrastando com o mouse.