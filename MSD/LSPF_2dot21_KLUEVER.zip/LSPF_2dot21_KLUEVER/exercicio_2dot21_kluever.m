%Porto Velho - RO, 7 de novembro de 2019 - Larissa Samara Paula de França.
%Exercício 2.21 (KLUEVER)

%Definindo as variáveis.
v1 = 0.06; %Velocidade 1.
v2 = 0.19; %Velocidade 2.
x_dot = linspace(-1.5,1.5,1000); %Range da velocidade relativa.

%Equação da força de amortecimento.
Fa = (3389 .* (x_dot - v1)./(sqrt((x_dot - v1).^2) + v2.^2)) + 1020.84;

plot(x_dot,Fa,'red'); %Gráfico.
grid on
title('Exercício 2.21 (KLUEVER)'); %Título do gráfico.
xlabel('Velocidade relativa (m/s)'); %Nome do eixo x.
ylabel('Força de amortecimento (N)'); %Nome do eixo y.
legend('Força de Amortecimento Não Linear'); %Legenda.