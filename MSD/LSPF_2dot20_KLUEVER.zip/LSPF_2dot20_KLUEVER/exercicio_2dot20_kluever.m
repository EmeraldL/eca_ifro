%Porto Velho - RO, 6 de novembro de 2019 - Larissa Samara Paula de França.
%Exercício 2.20 (KLUEVER)

%Definindo as variáveis.
v = 0.2; %Velocidade.
x_dot = linspace(-1.5,1.5,1000); %Range da velocidade relativa.

%Equação da força de amortecimento.
Fa = (4500 .* x_dot)./(sqrt((x_dot.^2) + (v.^2)));

plot(x_dot,Fa,'red'); %Gráfico.
grid on
title('Exercício 2.20 (KLUEVER)'); %Título do gráfico.
xlabel('Velocidade relativa (m/s)'); %Nome do eixo x.
ylabel('Força de amortecimento (N)'); %Nome do eixo y.
legend('Amortecimento Linear'); %Legenda.