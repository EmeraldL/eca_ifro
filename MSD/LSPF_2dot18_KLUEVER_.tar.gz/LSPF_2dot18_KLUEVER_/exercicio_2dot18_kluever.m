%Porto Velho - RO, 6 de novembro de 2019 - Larissa Samara Paula de França.
%Exercício 2.18 (KLUEVER)

%Definindo os valores para as deformações, sendo
%x1 para mola 1 e x2 para a mola 2.
x1 = [-7.2055 -6.2354 -4.6099 -3.1938 -1.8822 -1.2482 0 1.2482 1.8822 3.1938 4.6099 6.2354 7.2055]';
x2 = [-5.8411 -5.2570 -4.0888 -2.9206 -1.7523 -1.1682 0 1.1682 1.7523 2.9206 4.0888 5.2570 5.8411]';
y = [-50 -45 -35 -25 -15 -10 0 10 15 25 35 45 50]'; %Definindo valores da força aplicada.

p1 = polyfit(x1,y,1); %Polyfit para a mola 1.
p2 = polyfit(x2,y,1); %Polyfit para a mola 2.

pp1 = polyval(p1,x1); %Polyval para a mola 1.
pp2 = polyval(p2,x2); %Polyval para a mola 2.

hold on %Garante que os dois plots sairão na mesma figura.
plot(x1,y,'green',x1,pp1,'blue'); %Gráfico da mola 1.
plot(x2,y,'red',x2,pp2,'black *'); %Gráfico da mola 2.

title('Exercício 2.18 (KLUEVER)'); %Inserindo título.
xlabel('Deformação (mm)'); %Inserindo informação do eixo x.
ylabel('Força de Carregamento (N)'); %Inserindo informação do eixo y.
legend('Mola 1','Ajuste 1','Mola 2','Ajuste 2'); %Inserindo legenda. OBS: ajustar com o mouse depois.